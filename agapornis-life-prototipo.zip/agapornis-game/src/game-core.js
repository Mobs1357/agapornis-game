export const DEFAULT_AVIARY = { width: 10, depth: 8, height: 5 };

export function createInitialState() {
  return {
    coins: 500,
    selectedAviaryId: "aviary-1",
    aviaries: [{ id: "aviary-1", name: "Viveiro principal", capacity: 8, width: 10, depth: 8 }],
    birds: [
      { id: "bird-1", name: "Louro", sex: "Macho", color: 0x36a96b, aviaryId: "aviary-1", x: -1.4, z: 0, y: 0, ageDays: 420, hunger: 20, happiness: 85 },
      { id: "bird-2", name: "Luna", sex: "Fêmea", color: 0x55b98a, aviaryId: "aviary-1", x: 1.2, z: 0.8, y: 0, ageDays: 390, hunger: 15, happiness: 90 }
    ],
    objects: [
      { id: "nest-1", type: "nest", aviaryId: "aviary-1", x: -3.5, y: 2.2, z: -2.5 },
      { id: "perch-1", type: "perch", aviaryId: "aviary-1", x: 0, y: 1.5, z: 0 },
      { id: "feeder-1", type: "feeder", aviaryId: "aviary-1", x: 3.2, y: 0.35, z: -2 }
    ]
  };
}

export class AviaryGame {
  constructor(state = createInitialState()) {
    this.state = structuredClone(state);
    this.validateState();
  }
  validateState() {
    const aviaryIds = new Set(this.state.aviaries.map(a => a.id));
    if (aviaryIds.size !== this.state.aviaries.length) throw new Error("IDs de viveiro duplicados.");
    const birdIds = new Set();
    for (const bird of this.state.birds) {
      if (birdIds.has(bird.id)) throw new Error("ID de ave duplicado.");
      birdIds.add(bird.id);
      if (!aviaryIds.has(bird.aviaryId)) throw new Error(`Ave ${bird.id} vinculada a viveiro inexistente.`);
      this.assertInside(bird, this.getAviary(bird.aviaryId));
    }
    const objectIds = new Set();
    for (const object of this.state.objects) {
      if (objectIds.has(object.id)) throw new Error("ID de objeto duplicado.");
      objectIds.add(object.id);
      if (!aviaryIds.has(object.aviaryId)) throw new Error(`Objeto ${object.id} vinculado a viveiro inexistente.`);
      this.assertInside(object, this.getAviary(object.aviaryId));
    }
    for (const aviary of this.state.aviaries) {
      if (this.birdsIn(aviary.id).length > aviary.capacity) throw new Error(`Capacidade excedida em ${aviary.name}.`);
    }
    return true;
  }
  getAviary(id) {
    const aviary = this.state.aviaries.find(a => a.id === id);
    if (!aviary) throw new Error("Viveiro não encontrado.");
    return aviary;
  }
  birdsIn(aviaryId) { return this.state.birds.filter(b => b.aviaryId === aviaryId); }
  objectsIn(aviaryId) { return this.state.objects.filter(o => o.aviaryId === aviaryId); }
  assertInside(point, aviary) {
    const hw = aviary.width / 2, hd = aviary.depth / 2;
    if (!Number.isFinite(point.x) || !Number.isFinite(point.z) || point.x < -hw || point.x > hw || point.z < -hd || point.z > hd) {
      throw new Error("Posição fora dos limites do viveiro.");
    }
  }
  addAviary({ id, name, capacity = 8, width = DEFAULT_AVIARY.width, depth = DEFAULT_AVIARY.depth }) {
    if (!id || this.state.aviaries.some(a => a.id === id)) throw new Error("ID de viveiro inválido ou duplicado.");
    if (!Number.isInteger(capacity) || capacity < 1 || width <= 0 || depth <= 0) throw new Error("Dimensões ou capacidade inválidas.");
    this.state.aviaries.push({ id, name: name || id, capacity, width, depth });
    return this.getAviary(id);
  }
  addBird(bird) {
    if (!bird?.id || this.state.birds.some(b => b.id === bird.id)) throw new Error("Ave inválida ou já cadastrada.");
    const aviary = this.getAviary(bird.aviaryId);
    if (this.birdsIn(aviary.id).length >= aviary.capacity) throw new Error("Viveiro sem capacidade disponível.");
    const normalized = { hunger: 0, happiness: 75, ageDays: 30, y: 0, ...bird };
    this.assertInside(normalized, aviary);
    this.state.birds.push(normalized);
    return normalized;
  }
  addObject(object) {
    if (!object?.id || this.state.objects.some(o => o.id === object.id)) throw new Error("Objeto inválido ou já cadastrado.");
    this.assertInside(object, this.getAviary(object.aviaryId));
    this.state.objects.push({ ...object });
    return object;
  }
  moveBird(birdId, x, z) {
    const bird = this.state.birds.find(b => b.id === birdId);
    if (!bird) throw new Error("Ave não encontrada.");
    this.assertInside({ x, z }, this.getAviary(bird.aviaryId));
    bird.x = x; bird.z = z;
    return bird;
  }
  transferBird(birdId, destinationId) {
    const bird = this.state.birds.find(b => b.id === birdId);
    if (!bird) throw new Error("Ave não encontrada.");
    const destination = this.getAviary(destinationId);
    if (bird.aviaryId === destinationId) return bird;
    if (this.birdsIn(destinationId).length >= destination.capacity) throw new Error("Viveiro de destino está cheio.");
    bird.aviaryId = destinationId;
    bird.x = Math.max(-destination.width / 2 + 0.4, Math.min(destination.width / 2 - 0.4, bird.x));
    bird.z = Math.max(-destination.depth / 2 + 0.4, Math.min(destination.depth / 2 - 0.4, bird.z));
    bird.y = 0;
    return bird;
  }
  placeObject(objectId, destinationId, x, y, z) {
    const object = this.state.objects.find(o => o.id === objectId);
    if (!object) throw new Error("Objeto não encontrado.");
    this.assertInside({ x, z }, this.getAviary(destinationId));
    Object.assign(object, { aviaryId: destinationId, x, y, z });
    return object;
  }
  selectAviary(id) { this.getAviary(id); this.state.selectedAviaryId = id; return id; }
  tickDay() {
    for (const bird of this.state.birds) {
      bird.ageDays += 1;
      bird.hunger = Math.min(100, bird.hunger + 12);
      bird.happiness = Math.max(0, bird.happiness - 2);
    }
    return this.state;
  }
  save() { return JSON.stringify({ version: 1, state: this.state }); }
  static load(serialized) {
    const parsed = JSON.parse(serialized);
    if (parsed.version !== 1 || !parsed.state) throw new Error("Versão de salvamento incompatível.");
    return new AviaryGame(parsed.state);
  }
}
