import test from 'node:test';
import assert from 'node:assert/strict';
import { AviaryGame, createInitialState } from '../src/game-core.js';

test('inicia com um viveiro, duas aves e objetos', () => {
  const game = new AviaryGame();
  assert.equal(game.state.aviaries.length, 1);
  assert.equal(game.birdsIn('aviary-1').length, 2);
  assert.equal(game.objectsIn('aviary-1').length, 3);
});

test('cria viveiro e transfere ave atualizando vínculo', () => {
  const game = new AviaryGame();
  game.addAviary({ id: 'aviary-2', name: 'Viveiro 2', capacity: 3 });
  const bird = game.transferBird('bird-1', 'aviary-2');
  assert.equal(bird.aviaryId, 'aviary-2');
  assert.equal(game.birdsIn('aviary-1').length, 1);
  assert.equal(game.birdsIn('aviary-2').length, 1);
});

test('impede movimento para fora dos limites', () => {
  const game = new AviaryGame();
  assert.throws(() => game.moveBird('bird-1', 99, 0), /fora dos limites/);
});

test('impede lotação acima da capacidade', () => {
  const state = createInitialState();
  state.aviaries[0].capacity = 2;
  const game = new AviaryGame(state);
  assert.throws(() => game.addBird({ id: 'bird-3', aviaryId: 'aviary-1', x: 0, z: 0 }), /sem capacidade/);
});

test('impede transferência para viveiro cheio', () => {
  const game = new AviaryGame();
  game.addAviary({ id: 'aviary-2', capacity: 1 });
  game.addBird({ id: 'bird-3', aviaryId: 'aviary-2', x: 0, z: 0 });
  assert.throws(() => game.transferBird('bird-1', 'aviary-2'), /está cheio/);
});

test('posiciona objeto no viveiro e respeita bordas', () => {
  const game = new AviaryGame();
  game.addAviary({ id: 'aviary-2' });
  const obj = game.placeObject('nest-1', 'aviary-2', 2, 2, -2);
  assert.equal(obj.aviaryId, 'aviary-2');
  assert.throws(() => game.placeObject('nest-1', 'aviary-2', 8, 2, 0), /fora dos limites/);
});

test('salva e carrega o estado sem perder aves ou viveiros', () => {
  const game = new AviaryGame();
  game.addAviary({ id: 'aviary-2' });
  const restored = AviaryGame.load(game.save());
  assert.equal(restored.state.aviaries.length, 2);
  assert.equal(restored.state.birds.length, 2);
});

test('avanço de dia atualiza idade, fome e felicidade com limites', () => {
  const game = new AviaryGame();
  const before = game.state.birds[0];
  const age = before.ageDays;
  game.tickDay();
  assert.equal(before.ageDays, age + 1);
  assert.equal(before.hunger, 32);
  assert.equal(before.happiness, 83);
});
